# BP-03 Cryptographic Solver

## 1. Overview & Learning Outcome (LO3)
This script (`bp03_solver.py`) is the self-developed solver code created by **Member 2 (Sahil A V - IT24104236, Team 58)** for Stage 3 (BP-03) of Operation BlackPearl. It satisfies **Learning Outcome LO3**: *Develop exploitation and solver code to facilitate penetration testing and cryptanalysis*.

In addition, a minimal verification script (`decode_check.py`) is provided matching the exact test outputs in the Assignment 01 design proposal.

---

## 2. Requirements
- Python 3.8+ (Uses standard libraries: `base64`, `argparse`, `pathlib`, `re`, `sys`). No third-party dependencies required.

---

## 3. Usage & Execution
From the `scripts/` directory:

```bash
# Automated solve using default attachment path
python3 bp03_solver.py

# Solve a specific file path
python3 bp03_solver.py ../bp03/player/attacker_memo.txt

# Verbose execution showing intermediate cipher layer
python3 bp03_solver.py --verbose

# Save recovered intelligence report to an output file
python3 bp03_solver.py --output ../bp03/test-output/solver-evidence.txt

# Minimal Assignment 01 verification
python3 decode_check.py
```

---

## 4. Methodology & Internal Logic
1. **File Loading & Validation**:
   - Reads raw ciphertext string from `attacker_memo.txt`.
   - Validates existence and error-handles file access.
2. **Layer 1: Binary-to-Text Reversal (Base64)**:
   - Validates Base64 encoding structure and decodes bytes into UTF-8 text:
     `GWUK: IPC{mopfcyh_lntprzor_aece_zu_onbj} CQHGV: thrgq_jlvtf.kdx`
3. **Layer 2: Polyalphabetic Cryptanalysis (Vigenère)**:
   - Applies key `BLUEHARBOR` (derived from Stage 1 recon) or custom `--key`.
   - Reverses modular addition: `P_i = (C_i - K_i) mod 26`.
   - Preserves uppercase/lowercase formatting and punctuation.
4. **Automated Intelligence & Flag Extraction**:
   - Uses regex pattern `BPL\{[a-zA-Z0-9_\-]+\}` to extract flag: `BPL{layered_encoding_gave_it_away}`.
   - Parses the next-stage evidence target: `staff_photo.jpg`.

---

## 5. Test Results
- **Positive Test**: Tested against `attacker_memo.txt`.
  - Recovered flag: `BPL{layered_encoding_gave_it_away}`
  - Next handoff target: `staff_photo.jpg`
- **Minimal Script Test**: `decode_check.py` returns exact 2-line output from Assignment 01 report.
- **Negative Test (Wrong Key)**: Decrypted output remains scrambled; flag regex is not matched, triggering a clear warning.
- **Negative Test (Corrupted Data)**: Corrupted Base64 strings are caught with clear error feedback.

---

## 6. Access Separation
This solver script is part of the assessor and submission package for Member 2. Do not upload solver code to CTF players.
