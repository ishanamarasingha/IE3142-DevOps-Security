#!/usr/bin/env python3
"""Enforce reviewed lab exceptions without discarding raw scanner evidence."""
import collections
import datetime
import hashlib
import json
import pathlib
import sys


def evaluate(kind, report_path, exceptions_path):
    report = json.loads(pathlib.Path(report_path).read_text())
    exceptions = json.loads(pathlib.Path(exceptions_path).read_text())
    today = datetime.date.today().isoformat()
    for entry in exceptions:
        if not entry.get("reason") or entry["expires"] < today:
            raise ValueError("Missing justification or expired security exception")
    accepted = 0
    blocked = []
    if kind == "sast":
        if report.get("errors") or "results" not in report:
            raise ValueError("SAST report incomplete or scanner reported errors")
        allowance = collections.Counter()
        for e in exceptions:
            source = pathlib.Path(e["path"])
            if source.is_file() and hashlib.sha256(source.read_bytes()).hexdigest() == e["sha256"]:
                allowance[(e["rule"], e["path"], e["line"])] += 1
        for r in report["results"]:
            path = r["path"].removeprefix("/src/").removeprefix("./")
            key = (r["check_id"], path, r["start"]["line"])
            if allowance[key] > 0:
                accepted += 1
                allowance[key] -= 1
            else:
                blocked.append(f"{path}:{r['start']['line']} {r['check_id']}")
    elif kind == "secrets":
        if not isinstance(report, list):
            raise ValueError("Invalid secrets report")
        allowance = {e["fingerprint"] for e in exceptions}
        for r in report:
            if r["Fingerprint"] in allowance:
                accepted += 1
            else:
                blocked.append(f"{r['File']}:{r['StartLine']} {r['RuleID']}")
    elif kind in ("trivy", "sca", "container"):
        if report.get("SchemaVersion") != 2 or "Results" not in report:
            raise ValueError("Invalid Trivy report")
        results = report["Results"]
        if not isinstance(results, list) or not results:
            raise ValueError("Trivy did not analyze any targets")
        packages = {p["Name"] for r in results if r.get("Type") == "jar" for p in r.get("Packages", [])}
        required = {"org.apache.tomcat.embed:tomcat-embed-core", "com.fasterxml.jackson.core:jackson-databind", "tools.jackson.core:jackson-databind", "com.thoughtworks.xstream:xstream"}
        if kind in ("sca", "container") and not required.issubset(packages):
            raise ValueError(f"Runtime dependency coverage missing: {sorted(required - packages)}")
        if kind == "container" and not any(r.get("Class") == "os-pkgs" and r.get("Packages") for r in results):
            raise ValueError("Container operating system packages were not scanned")
        allowance = {(e["id"], e["package"], e["version"]) for e in exceptions}
        for result in report["Results"]:
            for r in result.get("Vulnerabilities") or []:
                if r["Severity"] not in ("HIGH", "CRITICAL"):
                    continue
                key = (r["VulnerabilityID"], r["PkgName"], r["InstalledVersion"])
                if key in allowance:
                    accepted += 1
                else:
                    blocked.append(f"{result['Target']} {key}")
    else:
        raise ValueError("Unknown scanner")
    print(f"{kind}: {accepted} reviewed lab findings, {len(blocked)} blocking findings")
    for finding in blocked:
        print(f"BLOCK: {finding}")
    return 1 if blocked else 0


if __name__ == "__main__":
    try:
        sys.exit(evaluate(*sys.argv[1:]))
    except (ValueError, KeyError, TypeError, OSError) as exc:
        print(f"Security gate could not validate evidence: {exc}", file=sys.stderr)
        sys.exit(2)
