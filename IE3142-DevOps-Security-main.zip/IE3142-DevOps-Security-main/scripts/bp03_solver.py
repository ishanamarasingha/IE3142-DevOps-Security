#!/usr/bin/env python3
"""
BP-03 Cryptographic Solver Script
Operation BlackPearl — Stage 3: The Encrypted Staff Memo
Course: IE3132 Penetration Testing (Assignment 02)
Student: Sahil A V (IT24104236) — Team 58
Role: Member 2 (Challenge Design A - Cryptography)

Learning Outcome LO3:
Self-developed exploitation/solver code to automate cryptanalysis,
decode binary-to-text representations, and solve polyalphabetic ciphers.
"""

import argparse
import base64
import re
import sys
from pathlib import Path


def decode_base64_layer(encoded_data: str) -> str:
    """
    Validates and decodes the Base64 encoding layer.
    """
    cleaned = "".join(encoded_data.split())
    try:
        decoded_bytes = base64.b64decode(cleaned, validate=True)
        return decoded_bytes.decode("utf-8")
    except Exception as exc:
        raise ValueError(f"Base64 decoding failed: {exc}")


def decrypt_vigenere(ciphertext: str, key: str) -> str:
    """
    Reverses Vigenère cipher substitution using the specified alphabetic key.
    Maintains uppercase and lowercase distinctions; ignores non-alphabetics.
    """
    if not key or not key.isalpha():
        raise ValueError("Vigenère key must contain only alphabetic characters.")

    key = key.upper()
    key_length = len(key)
    plaintext_chars = []
    key_index = 0

    for char in ciphertext:
        if char.isalpha():
            base = ord("A") if char.isupper() else ord("a")
            shift = ord(key[key_index % key_length]) - ord("A")
            decrypted_char = chr((ord(char) - base - shift) % 26 + base)
            plaintext_chars.append(decrypted_char)
            key_index += 1
        else:
            plaintext_chars.append(char)

    return "".join(plaintext_chars)


def extract_evidence(decrypted_text: str):
    """
    Extracts key investigative artifacts: Flag and Handoff Target image.
    """
    flag_match = re.search(r"BPL\{[a-zA-Z0-9_\-]+\}", decrypted_text)
    flag = flag_match.group(0) if flag_match else None

    image_match = re.search(r"IMAGE:\s*([a-zA-Z0-9_\-\.]+)", decrypted_text)
    next_evidence = image_match.group(1) if image_match else "staff_photo.jpg"

    return {
        "flag": flag,
        "next_evidence": next_evidence,
    }


def main():
    parser = argparse.ArgumentParser(
        description="Automated Cryptanalysis Solver for Challenge BP-03 (Stage 3)"
    )
    parser.add_argument(
        "ciphertext_file",
        nargs="?",
        default=str(
            Path(__file__).resolve().parents[1] / "bp03" / "player" / "attacker_memo.txt"
        ),
        help="Path to player attachment (default: bp03/player/attacker_memo.txt)",
    )
    parser.add_argument(
        "--key",
        default="BLUEHARBOR",
        help="Vigenère key derived from Stage 1 recon (default: BLUEHARBOR)",
    )
    parser.add_argument(
        "--output",
        help="Optional path to export decrypted memo and extracted tokens",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Display intermediate processing stages",
    )

    args = parser.parse_args()
    input_path = Path(args.ciphertext_file)

    if not input_path.exists():
        sys.exit(f"[-] Error: File not found: {input_path}")

    raw_content = input_path.read_text(encoding="utf-8")
    print(f"[*] Loaded raw ciphertext from: {input_path} ({len(raw_content)} bytes)")

    # Step 1: Base64 Decoding
    try:
        vigenere_layer = decode_base64_layer(raw_content)
        print(f"[+] Layer 1 reversed: Base64 decoded successfully ({len(vigenere_layer)} chars).")
        if args.verbose:
            preview = vigenere_layer.strip().replace("\n", " ")
            print(f"    [Intermediate Ciphertext]: {preview}")
    except ValueError as err:
        sys.exit(f"[-] {err}")

    # Step 2: Vigenère Decryption
    try:
        decrypted_memo = decrypt_vigenere(vigenere_layer, args.key)
        print(f"[+] Layer 2 reversed: Vigenère decrypted with key '{args.key}'.")
    except ValueError as err:
        sys.exit(f"[-] {err}")

    # Step 3: Extract Intelligence
    evidence = extract_evidence(decrypted_memo)

    print("\n" + "=" * 60)
    print("           OPERATION BLACKPEARL — STAGE 3 SOLVE REPORT")
    print("=" * 60)
    print(f"[!] Extracted Flag    : {evidence['flag']}")
    print(f"[>] Stage 4 Handoff   : {evidence['next_evidence']}")
    print("=" * 60 + "\n")

    if not evidence["flag"]:
        print("[-] Warning: Expected flag pattern BPL{...} not found in decrypted output.")
    else:
        print("[+] SUCCESS: Challenge BP-03 verified and solved!")

    # Output to file if requested
    if args.output:
        out_path = Path(args.output)
        report_content = (
            f"OPERATION BLACKPEARL — STAGE 3 SOLVER OUTPUT\n"
            f"Key: {args.key}\n"
            f"Flag: {evidence['flag']}\n"
            f"Handoff Target: {evidence['next_evidence']}\n"
            f"----------------------------------------\n\n"
            f"{decrypted_memo.strip()}\n"
        )
        out_path.write_text(report_content, encoding="utf-8")
        print(f"[+] Full investigation report exported to: {out_path}")


if __name__ == "__main__":
    main()
