import json
import pathlib
import tempfile
import unittest

from security_gate import evaluate


class SecurityGateTest(unittest.TestCase):
    def run_gate(self, kind, report, exceptions):
        with tempfile.TemporaryDirectory() as folder:
            root = pathlib.Path(folder)
            (root / "report.json").write_text(json.dumps(report))
            (root / "exceptions.json").write_text(json.dumps(exceptions))
            return evaluate(kind, root / "report.json", root / "exceptions.json")

    def test_new_secret_fingerprint_is_blocked(self):
        self.assertEqual(1, self.run_gate("secrets", [{"Fingerprint": "new", "File": "new.env", "StartLine": 1, "RuleID": "test"}], []))

    def test_new_high_dependency_is_blocked(self):
        report = {"SchemaVersion": 2, "Results": [{"Target": "app.jar", "Vulnerabilities": [{"VulnerabilityID": "CVE-test", "PkgName": "example", "InstalledVersion": "1", "Severity": "HIGH"}]}]}
        self.assertEqual(1, self.run_gate("trivy", report, []))

    def test_scan_error_does_not_pass_as_clean(self):
        with self.assertRaises(ValueError):
            self.run_gate("sast", {"results": [], "errors": ["scan failed"]}, [])
        with self.assertRaises(ValueError):
            self.run_gate("trivy", {}, [])

    def test_new_sast_finding_is_blocked(self):
        report = {"results": [{"path": "New.java", "check_id": "sql", "start": {"line": 1}}], "errors": []}
        self.assertEqual(1, self.run_gate("sast", report, []))

    def test_changed_source_invalidates_exception(self):
        report = {"results": [{"path": "scripts/security_gate.py", "check_id": "rule", "start": {"line": 1}}], "errors": []}
        exception = {"path": "scripts/security_gate.py", "rule": "rule", "line": 1, "sha256": "wrong", "reason": "fixture", "expires": "2099-01-01"}
        self.assertEqual(1, self.run_gate("sast", report, [exception]))

    def test_empty_scan_cannot_pass(self):
        for results in ([], [{"Target": "empty"}]):
            with self.assertRaises(ValueError):
                self.run_gate("sca", {"SchemaVersion": 2, "Results": results}, [])

    def test_expired_exception_blocks(self):
        with self.assertRaises(ValueError):
            self.run_gate("secrets", [], [{"reason": "fixture", "expires": "2000-01-01"}])

    def test_exact_cve_exception_does_not_allow_another_version(self):
        finding = {"VulnerabilityID": "CVE-test", "PkgName": "example", "InstalledVersion": "2", "Severity": "HIGH"}
        report = {"SchemaVersion": 2, "Results": [{"Target": "app.jar", "Vulnerabilities": [finding]}]}
        exception = {"id": "CVE-test", "package": "example", "version": "1", "reason": "fixture", "expires": "2099-01-01"}
        self.assertEqual(1, self.run_gate("trivy", report, [exception]))

    def test_clean_reports_pass(self):
        self.assertEqual(0, self.run_gate("sast", {"results": [], "errors": []}, []))
        self.assertEqual(0, self.run_gate("secrets", [], []))
        self.assertEqual(0, self.run_gate("trivy", {"SchemaVersion": 2, "Results": [{"Target": "app.jar"}]}, []))


if __name__ == "__main__":
    unittest.main()
