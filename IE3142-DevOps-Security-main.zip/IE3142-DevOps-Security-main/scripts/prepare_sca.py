#!/usr/bin/env python3
"""Scan the runtime libraries actually packaged into the executable Boot JAR."""
import pathlib
import sys
import zipfile


def extract(jar_path, destination):
    destination = pathlib.Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    count = 0
    with zipfile.ZipFile(jar_path) as archive:
        for member in archive.infolist():
            path = pathlib.PurePosixPath(member.filename)
            if path.parent == pathlib.PurePosixPath("BOOT-INF/lib") and path.suffix == ".jar":
                (destination / path.name).write_bytes(archive.read(member))
                count += 1
    if count == 0:
        raise ValueError("No BOOT-INF/lib dependencies found; refusing an empty SCA scan")
    print(f"Prepared {count} packaged runtime libraries for SCA")
    return count


if __name__ == "__main__":
    jars = list(pathlib.Path("target").glob("webgoat-*.jar"))
    if len(jars) != 1:
        sys.exit("Expected exactly one packaged WebGoat JAR")
    extract(jars[0], "target/sca-libs")
