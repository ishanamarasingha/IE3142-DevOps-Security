#!/usr/bin/env python3
"""
Simple verification script matching Assignment 01 testing evidence.
Decodes Base64 and decrypts Vigenère using key BLUEHARBOR.
"""
import base64
import sys
from pathlib import Path

def vigenere_decrypt(text: str, key: str) -> str:
    key = key.upper()
    res = []
    ki = 0
    for c in text:
        if c.isalpha():
            base = ord('A') if c.isupper() else ord('a')
            s = ord(key[ki % len(key)]) - ord('A')
            res.append(chr((ord(c) - base - s) % 26 + base))
            ki += 1
        else:
            res.append(c)
    return ''.join(res)

target = Path(__file__).resolve().parents[1] / "bp03" / "player" / "attacker_memo.txt"
if len(sys.argv) > 1:
    target = Path(sys.argv[1])

if not target.exists():
    sys.exit(f"File not found: {target}")

raw = target.read_text().strip()
vigenere_layer = base64.b64decode(raw).decode('utf-8')
plaintext = vigenere_decrypt(vigenere_layer, "BLUEHARBOR")
print(plaintext.strip())
