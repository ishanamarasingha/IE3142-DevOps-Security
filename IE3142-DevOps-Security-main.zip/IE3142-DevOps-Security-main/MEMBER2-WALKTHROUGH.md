# Member 2 Video Walkthrough Guide & Presentation Script
**Course:** IE3132 Penetration Testing  
**Component:** Assignment 02 — CTF Play Box Working Demonstration  
**Student:** Sahil A V (IT24104236) — Team 58  
**Role:** Member 2: Challenge Design A (Stage 3 — Cryptography: BP-03 "The Encrypted Staff Memo")  
**Target Video Duration:** ~4 to 5 minutes  

---

## Quick Reference / Cheat Sheet for Recording

| Item | Details |
|---|---|
| **Challenge ID** | BP-03 |
| **Title** | The Encrypted Staff Memo |
| **Category & Difficulty** | Cryptography / Moderate (150 Points) |
| **Prerequisite** | BP-02 (SQL Injection on Customer Portal) |
| **Player Attachment** | `attacker_memo.txt` |
| **Ciphertext Payload** | `R1dVSzogSVBDe21vcGZjeWhfbG50cHJ6b3JfYWVjZV96dV9vbmJqfQpDUUhHVjogdGhyZ3Ffamx2dGYua2R4Cg==` |
| **Encryption Pipeline** | Plaintext -> Vigenère Cipher (`BLUEHARBOR`) -> Base64 Encoding |
| **Official Flag** | `BPL{layered_encoding_gave_it_away}` |
| **Next Stage Link** | `IMAGE: staff_photo.jpg` for BP-04 (Steganography) |
| **Solver Code (LO3)** | `scripts/bp03_solver.py` (and verification script `scripts/decode_check.py`) |
| **Reset Script** | `bp03/organiser/reset.sh` |

---

## Step-by-Step Video Demonstration Script

### Segment 1: Introduction & Identification (0:00 - 0:30)
> **Visual:** Display your terminal or browser showing your student ID card or presentation title slide with:
> `Sahil A V | IT24104236 | Team 58 | Member 2: Challenge Design A (Stage 3: Cryptography)`.
>
> **Script / Speaking Notes:**  
> *"Hello everyone and welcome to my walkthrough of Stage 3 of the BlackPearl CTF. My name is Sahil A V, Student ID IT24104236 from Team 58. As Member 2, I am responsible for Challenge Design A. In this video segment, I will demonstrate Stage 3: Cryptography, titled 'The Encrypted Staff Memo' (BP-03). I will explain how this challenge was constructed, perform a live manual solve along the intended path, demonstrate my self-developed Python solver script meeting Learning Outcome LO3, show our hint structure, and test the stage reset mechanism."*

---

### Segment 2: Challenge Architecture & How It Was Built (0:30 - 1:30)
> **Visual:** Show directory layout and the generator script in terminal:
> ```bash
> ls -la bp03/ bp03/organiser/ bp03/player/
> cat bp03/organiser/plaintext_memo.txt
> cat bp03/organiser/generate_memo.py
> ```
>
> **Script / Speaking Notes:**  
> *"Let's examine how BP-03 was built. In our attack storyline, after Stage 2 where the participant exploits an SQL injection vulnerability on the customer portal, the authenticated shipments page directs the investigator to an intercepted communication file: `attacker_memo.txt`.
> 
> To reflect progressive difficulty (from Easy in Stage 1 & 2 to Moderate in Stage 3), I implemented a two-layer cryptographic scheme:
> 1. An inner polyalphabetic Vigenère cipher keyed with the project codename `BLUEHARBOR` which was recovered during Stage 1 OSINT reconnaissance in the WHOIS notes.
> 2. An outer binary-to-text Base64 encoding.
> 
> Here in the organiser directory, `generate_memo.py` takes our plaintext memo, performs Vigenère substitution, encodes the result in Base64, and places `attacker_memo.txt` into the player directory. The flag `BPL{layered_encoding_gave_it_away}` and the handoff pointer `IMAGE: staff_photo.jpg` are securely embedded inside."*

---

### Segment 3: Live Manual Solve Along the Intended Path (1:30 - 2:45)
> **Visual:** Terminal or CyberChef showing step-by-step player solving.
>
> **Commands to run live:**
> ```bash
> # 1. Inspect player attachment
> cat bp03/player/attacker_memo.txt
>
> # 2. Reverse Base64 layer
> base64 -d bp03/player/attacker_memo.txt
> # Displays: GWUK: IPC{mopfcyh_lntprzor_aece_zu_onbj} CQHGV: thrgq_jlvtf.kdx
>
> # 3. Decrypt with Vigenere using key BLUEHARBOR
> python3 scripts/decode_check.py
> ```
>
> **Script / Speaking Notes:**  
> *"Now I will demonstrate how a CTF participant solves BP-03 along the intended path:
> 
> 1. **Information Gathering:** The player downloads `attacker_memo.txt`. Viewing it, they see a string of ASCII characters ending in `==`. This signature pattern confirms Base64 encoding.
> 2. **Layer 1 Reversal:** Decoding using `base64 -d`, we uncover the intermediate text:
>    `GWUK: IPC{mopfcyh_lntprzor_aece_zu_onbj} CQHGV: thrgq_jlvtf.kdx`.
>    The colon, curly braces, and underscore formatting are preserved, but the characters are shifted.
> 3. **Cryptanalysis:** Because single substitution frequency analysis would not immediately yield readable English, the player recognizes a polyalphabetic Vigenère cipher.
> 4. **Key Derivation:** Recalling the intelligence from Stage 1, the player tests the operation codename `BLUEHARBOR` as the key.
> 5. **Decryption:** Decrypting with `BLUEHARBOR` reveals the plaintext:
>    `FLAG: BPL{layered_encoding_gave_it_away}`
>    `IMAGE: staff_photo.jpg`.
>    The player submits the flag to gain 150 points and receives the clue that `staff_photo.jpg` is the next target for Stage 4 Steganography."*

---

### Segment 4: Demonstration of Self-Developed Solver Script (LO3) (2:45 - 3:45)
> **Visual:** Terminal showing `scripts/bp03_solver.py` source code highlights and live execution.
>
> **Commands to run live:**
> ```bash
> # Run solver with verbose flag
> python3 scripts/bp03_solver.py --verbose
>
> # Run solver with output flag to record evidence
> python3 scripts/bp03_solver.py --output scripts/evidence.txt
> cat scripts/evidence.txt
> ```
>
> **Script / Speaking Notes:**  
> *"To fulfill Learning Outcome LO3, I developed an original Python solver and exploitation script, `bp03_solver.py`. 
> 
> Looking at the script design:
> - It accepts input file arguments, custom keys, and output flags via `argparse`.
> - It includes input validation and exception handling for malformed or corrupted Base64 data.
> - The core algorithm reverses modular addition using `(Cipher - Key) mod 26` while preserving letter casing.
> - It uses regular expressions to automatically extract the flag token `BPL{...}` and parse the handoff target `IMAGE: staff_photo.jpg`.
> 
> Executing it with `--verbose`, we see both layers decoded in real-time and the verified flag displayed in our formatted report. The `--output` flag writes the evidence to a structured text file for chain-of-custody documentation."*

---

### Segment 5: Hints System & Reset Mechanism (3:45 - 4:30)
> **Visual:** Display `hints.txt`, tamper with `attacker_memo.txt`, then run `reset.sh`.
>
> **Commands to run live:**
> ```bash
> # Display hint structure
> cat bp03/organiser/hints.txt
>
> # Simulate accidental corruption or modification by player
> echo "corrupted data" >> bp03/player/attacker_memo.txt
> cat bp03/player/attacker_memo.txt
>
> # Execute reset script
> bash bp03/organiser/reset.sh
>
> # Confirm restoration
> cat bp03/player/attacker_memo.txt
> ```
>
> **Script / Speaking Notes:**  
> *"For platform integration, we designed a progressive hint system:
> - **Hint 1 (Free):** Advises the player to work from the outermost transformation inward.
> - **Hint 2 (5-point penalty):** Identifies the outer layer as Base64.
> - **Hint 3 (10-point penalty):** Discloses the key `BLUEHARBOR` for the Vigenère cipher.
> 
> To ensure test repeatability and robust isolation, I built `reset.sh`. If a player tampers with or corrupts the attachment, running `bash reset.sh` cleans the directory and restores `attacker_memo.txt` from our pristine organiser backup with correct 644 permissions, restoring the stage in under one second."*

---

### Segment 6: Summary & Handover to Stage 4 (4:30 - 5:00)
> **Script / Speaking Notes:**  
> *"In summary, for Stage 3 I have:
> 1. Built and validated a fully working multi-layered cryptography challenge matching our approved design.
> 2. Demonstrated the live solve along the intended path using both manual tools and my self-developed LO3 Python solver.
> 3. Verified our hint penalties and reset mechanism.
> 4. Connected the narrative cleanly, handing over `staff_photo.jpg` to Member 3 for Stage 4 Steganography.
> 
> Thank you, and I now hand over the presentation to Member 3."*

---

## Assessor Marking Rubric Alignment Checklist

| Criterion | Target | How You Demonstrate It |
|---|---|---|
| **Functionality (25 pts)** | Stable, repeatable, matches design | Show generator, player file, and pristine backup working seamlessly. |
| **Technical Depth (20 pts)** | Strong tooling, original LO3 code | Run `bp03_solver.py` with `--verbose` and `--output`; explain modular math. |
| **Understanding (20 pts)** | Clear, live, unscripted explanation | Explain Base64 encoding vs. Vigenère encryption and key reuse in your own words. |
| **Security & Reset (10 pts)** | Isolation & reliable recovery | Demonstrate `reset.sh` restoring corrupted files from pristine storage. |
| **Design Fidelity (5 pts)** | Matches approved Assignment 01 design | Exact 100% match with Assignment 01 proposal (Sahil A V, Team 58). |
| **Integration (5 pts)** | Flag chain & stage dependencies | Show input from Stage 2 (SQLi leak) and output handoff to Stage 4 (`staff_photo.jpg`). |
| **Video Quality (5 pts)** | Clear, legible, within time limit | 720p+ terminal, clear audio, ~4-5 minute segment. |
| **Contribution (10 pts)** | Evidenced commit / configs / logs | Full folder `BP03-Member2-Cryptography` with `test-results.md` and solver logs. |
