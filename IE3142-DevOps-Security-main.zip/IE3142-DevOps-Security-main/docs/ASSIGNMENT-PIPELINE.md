# Assignment pipeline

The workflow builds and tests WebGoat on every push and pull request. It runs Semgrep Java SAST, full-history Gitleaks, Trivy dependency scanning of the built JAR, and Trivy scanning of the locally built Docker image. The aggregate Required security gates job requires every job to pass.

## September 30 pipeline repair

The previous SCA run used Trivy `fs`, which disables compiled-JAR analysis, and detected zero language files. It was not a clean dependency bill of health. `scripts/prepare_sca.py` now extracts the actual `BOOT-INF/lib/*.jar` files from the packaged executable JAR. Trivy `rootfs --pkg-types library` scans those compiled runtime libraries; the gate requires evidence that Tomcat, both Jackson generations and XStream were analyzed. The image gate also requires an OS package inventory. An empty or incomplete report fails closed.

The runtime BOM overrides upgrade Jackson 2 to 2.21.6, Jackson 3 to 3.1.6 and Tomcat to 11.0.26. The Docker build pulls the current base and installs available Ubuntu security updates, including the OpenSSL fix. HIGH/CRITICAL thresholds are unchanged. Actions and scanner containers are pinned to verified commit/image digests. Reports are retained for 30 days; download the evidence needed for the submission before it expires.

The 23 exact XStream 1.4.5 CVEs in `security/trivy-exceptions.json` remain accepted training risks. The original POM explicitly requires the old XStream for the vulnerable-components exercise, whose endpoint intentionally deserializes untrusted XML. Each exception names one CVE, package, version, reason, reference and expiry. No Jackson, Tomcat or Ubuntu vulnerability is exempted. New CVEs and different versions still block. This preserves the existing lesson; it does not secure that lesson or make the application suitable for public hosting.

## Gate policy

All new SAST and secret findings block. HIGH and CRITICAL dependency and image findings block. Scanner execution errors, unreadable reports and expired exceptions also block. Raw JSON reports and test results are uploaded even when a gate fails.

WebGoat is an intentionally vulnerable teaching application. The group chose to preserve its educational lessons. Exact reviewed exceptions in security/sast-exceptions.json identify each lesson finding by rule, path, line and source SHA-256. Changing that source invalidates its exception. These are accepted training risks, not vulnerability fixes. The WebWolf upload path traversal is remediated in FileServer.java and covered by rejection tests.

The 94 inherited history findings in security/secrets-exceptions.json are identified by commit-specific Gitleaks fingerprints. They include educational JWT/password fixtures, PEM delimiter false positives, historical training text and vendored parser dictionaries. Four findings are upstream Travis AWS access-key identifiers with encrypted counterpart secrets; the configuration is absent from the current tree and restricted to upstream deployment. Their revocation status is not known. No history has been rewritten, no secret value is included in the exception file, and adding a credential in a new commit still blocks.

Exceptions expire on 2026-12-31 and must be reviewed before renewal. Preserve these qualifications in the report: a passing training pipeline does not mean WebGoat is safe for public deployment or that all lesson vulnerabilities have been repaired. The assignment's four exploit-and-fix demonstrations remain separate required evidence.

## Evidence and secrets

Run 36693264794 captured actual gate failures: 17 Semgrep findings and 94 Gitleaks history findings. Preserve those run reports as blocking evidence. The policy regression tests verify that unreviewed findings, missing evidence and changed source cannot pass. Capture the final successful run after all checks complete.

Run [36695688524](https://github.com/It24101258/IE3142-DevOps-Security/actions/runs/36695688524), commit `857f948ae83f6243a4a52e35c35c87db8d46ae0f`, is additional real blocking evidence: the container gate found 30 HIGH/CRITICAL findings and the aggregate job failed. Seven were runtime/OS findings remediated by this repair; 23 were the deliberately vulnerable XStream dependency retained above. The dependency scan separately failed because its report contained no analyzed results. Never describe that run as a clean scan.

For the report, capture the successful run overview, each scanner's finding summary, Maven unit/integration test totals and the earlier failing container/aggregate jobs. Artifacts contain the raw JSON and JUnit XML. Record accepted teaching risks separately from fixed findings. A green status means this explicit policy passed on that commit with that vulnerability database, not that zero vulnerabilities exist.

The pipeline uses GitHub's automatically provisioned encrypted GITHUB_TOKEN with contents: read. Scanners and local image builds need no external credentials. Any application or publishing credentials must be configured through GitHub Actions encrypted secrets and injected at runtime. Do not commit them.

Configure main branch protection to require Required security gates. A failed workflow alone does not prevent an administrator from merging. The inherited upstream-only release workflow does not publish this group's image.

## Attribution

Disclose ChatGPT/Codex assistance for pipeline configuration, findings review, the upload fix, tests and documentation in the individual contribution statement. Review and understand the implementation before the viva.

## Patch references

- [FasterXML advisory for CVE-2026-68497](https://github.com/FasterXML/jackson-databind/security/advisories/GHSA-q4xh-88c3-wmh7)
- [Apache Tomcat 11 security advisories](https://tomcat.apache.org/security-11.html)
- [Ubuntu OpenSSL fix for CVE-2026-84782](https://ubuntu.com/security/CVE-2026-84782)
- [Spring Boot dependency version properties](https://docs.spring.io/spring-boot/appendix/dependency-versions/properties.html)

