/*
 * SPDX-FileCopyrightText: Copyright © 2018 WebGoat authors
 * SPDX-License-Identifier: GPL-2.0-or-later
 */
package org.owasp.webgoat.lessons.sqlinjection.introduction;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.owasp.webgoat.container.plugins.LessonTest;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

public class SqlInjectionLesson5aTest extends LessonTest {

  @Test
  public void knownAccountShouldDisplayData() throws Exception {
    // Verify that a valid account still returns the expected user data.
    mockMvc
        .perform(
            MockMvcRequestBuilders.post("/SqlInjection/assignment5a")
                .param("account", "Smith")
                .param("operator", "")
                .param("injection", ""))
        .andExpect(status().isOk())
        .andExpect(jsonPath("lessonCompleted", is(false)))
        .andExpect(jsonPath("$.output", containsString("<p>USERID, FIRST_NAME")))
        .andExpect(jsonPath("$.output", containsString("John, Smith,")));
  }

  @Test
  public void unknownAccountShouldReturnNoRecords() throws Exception {
    // Unknown accounts should not return database records.
    assertNoRecords("NONEXISTENT_SQLI_TEST_ACCOUNT", "", "");
  }

  @Test
  public void tautologyInjectionShouldReturnNoRecords() throws Exception {
    // Verify that a common OR-based SQL injection cannot bypass the query.
    assertNoRecords("'", "OR", "'1' = '1");
  }

  @Test
  public void browserAttackShouldReturnNoRecords() throws Exception {
    // Simulate an SQL injection payload submitted through the application.
    assertNoRecords("Smith'", "or", "'1' = '1");
  }

  @Test
  public void unmatchedQuoteShouldBeTreatedAsData() throws Exception {
    // Quotes in user input should be treated as data instead of SQL syntax.
    assertNoRecords("Smith'", "OR", "'1' = '1'");
  }

  private void assertNoRecords(String account, String operator, String injection)
      throws Exception {
    mockMvc
        .perform(
            MockMvcRequestBuilders.post("/SqlInjection/assignment5a")
                .param("account", account)
                .param("operator", operator)
                .param("injection", injection))
        .andExpect(status().isOk())
        .andExpect(jsonPath("lessonCompleted", is(false)))
        .andExpect(
            jsonPath(
                "$.feedback",
                is(messages.getMessage("sql-injection.5a.no.results"))))
        .andExpect(jsonPath("$.output", not(containsString("<p>USERID, FIRST_NAME"))))
        .andExpect(jsonPath("$.output", not(containsString("malformed string"))));
  }
}
