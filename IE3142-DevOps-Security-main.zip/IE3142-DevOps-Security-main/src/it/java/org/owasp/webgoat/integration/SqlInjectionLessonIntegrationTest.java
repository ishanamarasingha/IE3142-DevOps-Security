/*
 * SPDX-FileCopyrightText: Copyright © 2019 WebGoat authors
 * SPDX-License-Identifier: GPL-2.0-or-later
 */
package org.owasp.webgoat.integration;

import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class SqlInjectionLessonIntegrationTest extends IntegrationTest {

  public static final String sql_2 = "select department from employees where last_name='Franco'";
  public static final String sql_3 =
      "update employees set department='Sales' where last_name='Barnett'";
  public static final String sql_4_drop = "alter table employees drop column phone";
  public static final String sql_4_add = "alter table employees add column phone varchar(20)";
  public static final String sql_5 = "grant select on grant_rights to unauthorized_user";
  public static final String sql_9_account = " ' ";
  public static final String sql_9_operator = "or";
  public static final String sql_9_injection = "'1'='1";
  public static final String sql_10_login_count = "2";
  public static final String sql_10_userid = "1 or 1=1";

  public static final String sql_11_a = "Smith' or '1' = '1";
  public static final String sql_11_b = "3SL99A'  or '1'='1";

  public static final String sql_12_a = "Smith";
  public static final String sql_12_b =
      "3SL99A' ; update employees set salary= '100000' where last_name='Smith";

  public static final String sql_13 = "%update% '; drop table access_log ; --'";

  @Test
  public void runTests() {
    startLesson("SqlInjection");

    Map<String, Object> params = new HashMap<>();
    params.clear();
    params.put("query", sql_2);
      checkAssignment(webGoatUrlConfig.url("SqlInjection/attack2"), params, true);

    params.clear();
    params.put("query", sql_3);
      checkAssignment(webGoatUrlConfig.url("SqlInjection/attack3"), params, true);

    params.clear();
    params.put("query", sql_4_add);
      checkAssignment(webGoatUrlConfig.url("SqlInjection/attack4"), params, true);

    params.clear();
    params.put("query", sql_5);
      checkAssignment(webGoatUrlConfig.url("SqlInjection/attack5"), params, true);

    params.clear();
    params.put("operator", sql_9_operator);
    params.put("account", sql_9_account);
    params.put("injection", sql_9_injection);
         // The secured endpoint must reject the injection without returning user records.
    io.restassured.RestAssured.given()
        .relaxedHTTPSValidation()
        .cookie("JSESSIONID", getWebGoatCookie())
        .formParams(params)
        .post(webGoatUrlConfig.url("SqlInjection/assignment5a"))
        .then()
        .statusCode(200)
        .body("lessonCompleted", org.hamcrest.CoreMatchers.is(false))
        .body(
            "output",
            org.hamcrest.CoreMatchers.not(
                org.hamcrest.CoreMatchers.containsString("<p>USERID, FIRST_NAME")))
        .body(
            "feedback",
            org.hamcrest.CoreMatchers.containsString("No results matched"));

    params.clear();
    params.put("login_count", sql_10_login_count);
    params.put("userid", sql_10_userid);
      checkAssignment(webGoatUrlConfig.url("SqlInjection/assignment5b"), params, true);

    params.clear();
    params.put("name", sql_11_a);
    params.put("auth_tan", sql_11_b);
      checkAssignment(webGoatUrlConfig.url("SqlInjection/attack8"), params, true);

    params.clear();
    params.put("name", sql_12_a);
    params.put("auth_tan", sql_12_b);
      checkAssignment(webGoatUrlConfig.url("SqlInjection/attack9"), params, true);

    params.clear();
    params.put("action_string", sql_13);
      checkAssignment(webGoatUrlConfig.url("SqlInjection/attack10"), params, true);

        // Only the secured exercise should remain unsolved.
    java.util.List<Boolean> solved =
        io.restassured.RestAssured.given()
            .relaxedHTTPSValidation()
            .cookie("JSESSIONID", getWebGoatCookie())
            .get(webGoatUrlConfig.url("service/lessonoverview.mvc/SqlInjection.lesson"))
            .then()
            .statusCode(200)
            .extract()
            .jsonPath()
            .getList("solved", Boolean.class);

    org.hamcrest.MatcherAssert.assertThat(
        java.util.Collections.frequency(solved, false),
        org.hamcrest.CoreMatchers.is(1));
    org.hamcrest.MatcherAssert.assertThat(
        java.util.Collections.frequency(solved, true),
        org.hamcrest.CoreMatchers.is(solved.size() - 1));
  }
}
