/*
 * SPDX-FileCopyrightText: Copyright © 2017 WebGoat authors
 * SPDX-License-Identifier: GPL-2.0-or-later
 */
package org.owasp.webgoat.webwolf;

import static java.util.Comparator.comparing;
import static org.springframework.http.MediaType.ALL_VALUE;

import jakarta.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.attribute.FileTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.TimeZone;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

/** Controller for uploading a file */
@Controller
@Slf4j
public class FileServer {

  private static final DateTimeFormatter dateTimeFormatter =
      DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

  /** Messages shown on the files page, the upload redirects to it with one of them. */
  static final String UPLOAD_SUCCESSFUL = "File uploaded successful";

  static final String NOTHING_TO_UPLOAD = "Nothing to upload";
  static final String UPLOAD_TOO_LARGE = "File is too large to upload";

  @Value("${webwolf.fileserver.location}")
  private String fileLocation;

  @Value("${server.address}")
  private String server;

  @Value("${server.servlet.context-path}")
  private String contextPath;

  @Value("${server.port}")
  private int port;

  @RequestMapping(
      path = "/file-server-location",
      consumes = ALL_VALUE,
      produces = MediaType.TEXT_PLAIN_VALUE)
  @ResponseBody
  public String getFileLocation() {
    return fileLocation;
  }

  @PostMapping(value = "/fileupload")
  public ModelAndView importFile(
      @RequestParam("file") MultipartFile multipartFile, Authentication authentication)
      throws IOException {
    var username = authentication.getName();
    if (multipartFile == null
        || multipartFile.isEmpty()
        || !StringUtils.hasText(multipartFile.getOriginalFilename())) {
      log.debug("No file selected for upload by {}", username);
      return new ModelAndView(
          new RedirectView("files", true),
          new ModelMap().addAttribute("uploadSuccess", NOTHING_TO_UPLOAD));
    }

    var originalFilename = multipartFile.getOriginalFilename();
    var filename = FilenameUtils.getName(originalFilename);
    if (!filename.equals(originalFilename)
        || filename.equals(".")
        || filename.equals("..")
        || filename.contains(":")) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid upload filename");
    }
    if (!FilenameUtils.getName(username).equals(username)
        || username.equals(".")
        || username.equals("..")
        || username.contains(":")) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid upload user");
    }
    var root = Files.createDirectories(new File(fileLocation).toPath()).toRealPath();
    var destinationDir = root.resolve(username);
    if (Files.isSymbolicLink(destinationDir)) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid upload directory");
    }
    Files.createDirectories(destinationDir);
    if (!destinationDir.toRealPath().getParent().equals(root)) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid upload directory");
    }
    // DO NOT use multipartFile.transferTo(), see
    // https://stackoverflow.com/questions/60336929/java-nio-file-nosuchfileexception-when-file-transferto-is-called
    try (InputStream is = multipartFile.getInputStream()) {
      var destinationFile = destinationDir.resolve(filename);
      Files.deleteIfExists(destinationFile);
      Files.copy(is, destinationFile);
    }
    log.debug("File saved to {}", destinationDir.resolve(filename));

    return new ModelAndView(
        new RedirectView("files", true),
        new ModelMap().addAttribute("uploadSuccess", UPLOAD_SUCCESSFUL));
  }

  @GetMapping(value = "/files")
  public ModelAndView getFiles(
      HttpServletRequest request, Authentication authentication, TimeZone timezone) {
    String username = (null != authentication) ? authentication.getName() : "anonymous";
    File destinationDir = new File(fileLocation, username);

    ModelAndView modelAndView = new ModelAndView();
    modelAndView.setViewName("files");
    // the message of the upload we are redirected from, see importFile and
    // FileUploadExceptionAdvice
    var uploadMessage = request.getParameter("uploadSuccess");
    if (StringUtils.hasText(uploadMessage)) {
      modelAndView.addObject("uploadSuccess", uploadMessage);
      modelAndView.addObject("uploadFailed", !UPLOAD_SUCCESSFUL.equals(uploadMessage));
    }

    record UploadedFile(String name, String size, String link, String creationTime) {}

    var uploadedFiles = new ArrayList<UploadedFile>();
    File[] files = destinationDir.listFiles(File::isFile);
    if (files != null) {
      for (File file : files) {
        String size = FileUtils.byteCountToDisplaySize(file.length());
        String link = String.format("files/%s/%s", username, file.getName());
        uploadedFiles.add(
            new UploadedFile(file.getName(), size, link, getCreationTime(timezone, file)));
      }
    }

    modelAndView.addObject(
        "files",
        uploadedFiles.stream().sorted(comparing(UploadedFile::creationTime).reversed()).toList());
    modelAndView.addObject("webwolf_url", "http://" + server + ":" + port + contextPath);
    return modelAndView;
  }

  private String getCreationTime(TimeZone timezone, File file) {
    try {
      FileTime creationTime = (FileTime) Files.getAttribute(file.toPath(), "creationTime");
      ZonedDateTime zonedDateTime = creationTime.toInstant().atZone(timezone.toZoneId());
      return dateTimeFormatter.format(zonedDateTime);
    } catch (IOException e) {
      return "unknown";
    }
  }
}
