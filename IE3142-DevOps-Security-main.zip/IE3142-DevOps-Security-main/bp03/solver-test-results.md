# BP-03 Solver Test Results

**Solver:** `scripts/bp03_solver.py`  
**Learning Outcome:** LO3 (Exploitation and Solver Development)  
**Author:** Sahil A V (IT24104236) — Team 58  

| Test | Status | Observed result |
|---|---|---|
| Automated decryption | PASS | Successfully reversed Base64 and Vigenère layers; extracted flag `BPL{layered_encoding_gave_it_away}` |
| Handoff target identification | PASS | Extracted next evidence target: `staff_photo.jpg` |
| Output file export | PASS | Option `--output` wrote structured intelligence report to target file |
| Verbose logging mode | PASS | Option `--verbose` displays intermediate character previews and stage steps |
| Error handling (Invalid file) | PASS | Gracefully exits with error `File not found` when path is missing |
| Error handling (Corrupted base64) | PASS | Catches decoding failure and outputs `Base64 decoding failed` |
| Incorrect key detection | PASS | Detects when flag regex is missing and warns user of invalid key |

Verification completed and verified against pristine player attachment.
