# BP-03 — The Encrypted Staff Memo

Domain: Cryptography  
Difficulty: Moderate  
Points: 150  
Prerequisite: BP-02 (SQL Injection on Customer Portal)  
Responsible Member: Member 2 (Sahil A V - IT24104236, Team 58)  

---

## 1. Requirements
- Python 3 standard library (`base64`, `argparse`, `pathlib`, `re`, `sys`).
- Standard terminal tools (`base64`, `tr`, `xxd`) or CyberChef.

---

## 2. Challenge Build
From this `bp03` directory, run:

```bash
python3 organiser/generate_memo.py
```

The generator:
1. Reads `organiser/plaintext_memo.txt` containing the flag and the next stage reference `IMAGE: staff_photo.jpg`.
2. Applies a polyalphabetic Vigenère cipher with the operation codename `BLUEHARBOR` recovered in Stage 1.
3. Encodes the resulting ciphertext in standard Base64:
   `R1dVSzogSVBDe21vcGZjeWhfbG50cHJ6b3JfYWVjZV96dV9vbmJqfQpDUUhHVjogdGhyZ3Ffamx2dGYua2R4Cg==`
4. Writes the player attachment to `player/attacker_memo.txt`.
5. Updates `organiser/pristine_attacker_memo.txt` for clean reset restoration.

---

## 3. Player Experience & Run
The player receives only `player/attacker_memo.txt` through the CTF platform.

To examine the file:
```bash
cat player/attacker_memo.txt
```

---

## 4. Intended Solution Path
1. **Information Gathering**: Inspect `attacker_memo.txt` and identify Base64 encoding.
2. **Layer 1 Decoding**:
   ```bash
   base64 -d player/attacker_memo.txt
   # Output: GWUK: IPC{mopfcyh_lntprzor_aece_zu_onbj} CQHGV: thrgq_jlvtf.kdx
   ```
3. **Cryptanalysis & Key Association**:
   Identify Vigenère cipher. The key is the project codename recovered during Stage 1 OSINT: `BLUEHARBOR`.
4. **Layer 2 Decryption**:
   Decrypt using key `BLUEHARBOR` (via CyberChef, `decode_check.py`, or `scripts/bp03_solver.py`).
5. **Flag & Handoff**:
   - Flag: `BPL{layered_encoding_gave_it_away}`
   - Handoff: `IMAGE: staff_photo.jpg` (proceeds to Stage 4 Steganography / BP-04).

---

## 5. Reset Mechanism
Restore the approved pristine copy:

```bash
bash organiser/reset.sh
```

---

## 6. Platform Integration
- **Upload**: `player/attacker_memo.txt` as the challenge attachment.
- **Description**: `organiser/challenge-description.txt`.
- **Hints**: `organiser/hints.txt` (Free, 5-pt penalty, 10-pt penalty).
- **Prerequisite**: BP-02 completion.
- **Expected Flag**: `BPL{layered_encoding_gave_it_away}`.

---

## 7. Access Separation
The `organiser/` directory, generator code, pristine copies, solutions, and this implementation README are for organisers and assessors. Players receive only `player/attacker_memo.txt`.
