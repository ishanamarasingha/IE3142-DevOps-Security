#!/bin/bash
set -eu

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "[*] Resetting Challenge BP-03 (Stage 3 - Cryptography)..."

# Ensure directories exist
mkdir -p "$BASE_DIR/player" "$BASE_DIR/organiser"

# Verify pristine file exists, regenerate if needed
if [ ! -f "$BASE_DIR/organiser/pristine_attacker_memo.txt" ]; then
    echo "[-] Warning: Pristine copy missing. Regenerating..."
    python3 "$BASE_DIR/organiser/generate_memo.py"
fi

# Restore pristine player file
cp -f "$BASE_DIR/organiser/pristine_attacker_memo.txt" "$BASE_DIR/player/attacker_memo.txt"
chmod 644 "$BASE_DIR/player/attacker_memo.txt"

# Also maintain backward compatibility
if [ -f "$BASE_DIR/organiser/pristine_encrypted_memo.txt" ]; then
    cp -f "$BASE_DIR/organiser/pristine_encrypted_memo.txt" "$BASE_DIR/player/encrypted_memo.txt" 2>/dev/null || true
fi

# Remove any temporary solver or test outputs
rm -f "$BASE_DIR/player/"*.tmp "$BASE_DIR/player/"*.out 2>/dev/null || true

echo "[+] Challenge BP-03 successfully restored to pristine state."
echo "[+] Player attachment ready at: $BASE_DIR/player/attacker_memo.txt"
