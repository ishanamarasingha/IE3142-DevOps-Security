import argparse
import base64
from pathlib import Path

def vigenere_encrypt(text: str, key: str) -> str:
    """
    Encrypts alphabetic characters using the Vigenère cipher with the given key.
    Preserves casing and leaves non-alphabetic characters unchanged.
    """
    key = key.upper()
    key_length = len(key)
    result = []
    key_index = 0

    for char in text:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            shift = ord(key[key_index % key_length]) - ord('A')
            encrypted_char = chr((ord(char) - base + shift) % 26 + base)
            result.append(encrypted_char)
            key_index += 1
        else:
            result.append(char)
    return "".join(result)

def main():
    parser = argparse.ArgumentParser(description="Generate BP-03 encrypted memo")
    parser.add_argument(
        "--input",
        type=Path,
        default=Path(__file__).resolve().parent / "plaintext_memo.txt",
        help="Path to plaintext memo",
    )
    parser.add_argument(
        "--key",
        default="BLUEHARBOR",
        help="Vigenère cipher encryption key (default: BLUEHARBOR)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "player" / "encrypted_memo.txt",
        help="Path for player output file",
    )
    args = parser.parse_args()

    if not args.input.exists():
        raise FileNotFoundError(f"Plaintext input file not found: {args.input}")

    plaintext = args.input.read_text(encoding="utf-8")
    print(f"Loaded plaintext from: {args.input} ({len(plaintext)} characters)")

    # Step 1: Vigenère Cipher Encryption
    vigenere_cipher = vigenere_encrypt(plaintext, args.key)

    # Step 2: Base64 Encoding
    b64_encoded = base64.b64encode(vigenere_cipher.encode("utf-8")).decode("utf-8")

    # Write to player destination
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(b64_encoded, encoding="utf-8")
    print(f"Player attachment generated: {args.output} ({len(b64_encoded)} bytes)")

    # Also update pristine copy for organiser reset mechanism
    pristine_path = Path(__file__).resolve().parent / "pristine_encrypted_memo.txt"
    pristine_path.write_text(b64_encoded, encoding="utf-8")
    print(f"Pristine backup updated: {pristine_path}")

    print("\n[SUCCESS] BP-03 Challenge Artifacts Successfully Generated.")
    print(f"Encryption Key: {args.key}")
    print("Pipeline: Plaintext -> Vigenère Cipher -> Base64 Encoding")

if __name__ == "__main__":
    main()
