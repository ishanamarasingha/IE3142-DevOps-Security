# BP-03 Test Results

**Challenge:** BP-03 — The Encrypted Staff Memo  
**Domain:** Cryptography  
**Member:** Sahil A V (IT24104236) — Team 58 — Member 2  

| Test | Expected result | Status | Evidence |
|---|---|---|---|
| Cipher generation | `generate_memo.py` outputs Base64 encoded Vigenère ciphertext matching Assignment 01 proposal | PASS | `R1dVSzogSVBDe21vcGZjeWhfbG50cHJ6b3JfYWVjZV96dV9vbmJqfQpDUUhHVjogdGhyZ3Ffamx2dGYua2R4Cg==` generated |
| Manual CLI decoding | `base64 -d player/attacker_memo.txt` recovers intermediate ciphertext | PASS | Output: `GWUK: IPC{mopfcyh_lntprzor_aece_zu_onbj} CQHGV: thrgq_jlvtf.kdx` |
| Vigenère decryption | Decryption using key `BLUEHARBOR` recovers flag and next image target | PASS | Recovered `FLAG: BPL{layered_encoding_gave_it_away}` and `IMAGE: staff_photo.jpg` |
| Python verification | `decode_check.py` matches Assignment 01 proposal test output verbatim | PASS | Clean two-line output verified |
| LO3 Solver execution | `scripts/bp03_solver.py` automatically decodes both layers and regex-extracts flag | PASS | Verified with `--verbose` and `--output` flags |
| Stage reset | `reset.sh` cleans player directory and restores `attacker_memo.txt` from pristine copy | PASS | Terminal execution verified in under 1 second |
| Cross-stage dependency | Key derived from Stage 1 WHOIS notes (`BLUEHARBOR`); handoff points to Stage 4 (`staff_photo.jpg`) | PASS | Seamless integration in BlackPearl attack chain |
| Leakage prevention | Organiser generator and solutions stored strictly in `organiser/` and `scripts/` | PASS | Player receives only `attacker_memo.txt` |
